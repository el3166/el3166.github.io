# Photo Album #

## About ##

Frontend for Photo Album assignment by Emily Liang (el3166) and Yichen Liu (yl4854).
